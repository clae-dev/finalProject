import React, { useContext } from 'react';
import { AuthContext } from './AuthContext';

/**
 * 마이페이지 컴포넌트 (학원 패턴)
 * - 로그인한 사용자 정보 표시
 */

function MyPage() {
  const { user } = useContext(AuthContext);

  return (
    <div className="max-w-2xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold text-gray-800 mb-8">마이페이지</h2>

      <div className="bg-white rounded-xl shadow-md p-6 border border-gray-100 mb-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 pb-4 border-b border-gray-100">
          회원 정보
        </h3>

        <div className="space-y-4">
          <div className="flex items-center py-2">
            <span className="w-28 text-gray-500 font-medium">회원 번호</span>
            <span className="text-gray-800">{user.memberNo}</span>
          </div>
          <div className="flex items-center py-2">
            <span className="w-28 text-gray-500 font-medium">이름</span>
            <span className="text-gray-800">{user.memberName}</span>
          </div>
          <div className="flex items-center py-2">
            <span className="w-28 text-gray-500 font-medium">닉네임</span>
            <span className="text-gray-800">{user.memberNickname}</span>
          </div>
          <div className="flex items-center py-2">
            <span className="w-28 text-gray-500 font-medium">이메일</span>
            <span className="text-gray-800">{user.memberEmail}</span>
          </div>
        </div>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => alert('프로필 수정 기능은 준비 중입니다.')}
          className="flex-1 bg-primary-600 hover:bg-primary-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors duration-200"
        >
          프로필 수정
        </button>
        <button
          onClick={() => alert('내 활동 조회 기능은 준비 중입니다.')}
          className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-3 px-4 rounded-lg transition-colors duration-200"
        >
          내 활동 조회
        </button>
      </div>
    </div>
  );
}

export default MyPage;
